module.exports = {
  runtimeCompiler: true,
  devServer: {
    host: 'localhost',
    port: 3010
  }
}
