//
// Diese Datei wurde mit der JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.7 generiert 
// Siehe <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Änderungen an dieser Datei gehen bei einer Neukompilierung des Quellschemas verloren. 
// Generiert: 2019.01.11 um 04:30:38 PM CET 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://lm.com/ccore", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.lm.ccore;
