const AppConstant = {
    API_V1: 'api'
}

export default AppConstant