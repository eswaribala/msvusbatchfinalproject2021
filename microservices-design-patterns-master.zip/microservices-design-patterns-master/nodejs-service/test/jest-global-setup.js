const mongoServer = require('./mongodb-memory');

module.exports = async () => mongoServer();