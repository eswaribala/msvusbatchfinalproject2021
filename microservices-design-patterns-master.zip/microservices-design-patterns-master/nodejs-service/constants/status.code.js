module.exports = {
    STATUS:  {
        UPDATE_CODE : 204,
        CREATE_CODE: 201,
        GET_CODE: 200
    }
};