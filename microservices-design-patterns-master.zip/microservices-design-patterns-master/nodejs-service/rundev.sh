#!/bin/bash
mongod &
cd ~/WebstormProjects/projects/week-menu-api
npm run dev
