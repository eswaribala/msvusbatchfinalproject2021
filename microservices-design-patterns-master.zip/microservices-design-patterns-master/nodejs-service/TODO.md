## Product

- Product service save

 * validation
   1 - product needs a category