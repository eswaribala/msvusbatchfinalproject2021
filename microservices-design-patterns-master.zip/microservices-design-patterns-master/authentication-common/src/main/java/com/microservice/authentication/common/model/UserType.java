package com.microservice.authentication.common.model;

public enum UserType {
    GOOGLE, FACEBOOK, GITHUB
}
