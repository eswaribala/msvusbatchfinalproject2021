export {
    NativeRouter as Router,
    Switch,
    Route,
    Link
} from 'react-router-native';
